### 1.0.7 ###

# 新增短信设置
INSERT INTO `yoshop_setting` VALUES ('sms', '短信设置', '{"default":"aliyun","engine":{"aliyun":{"AccessKeyId":"","AccessKeySecret":"","sign":"","order_pay":{"is_enable":"0","template_code":"","accept_phone":""}}}}', 10001, 1530265122);

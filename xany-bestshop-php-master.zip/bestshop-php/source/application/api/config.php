<?php

return [
    // 默认输出类型
    'default_return_type'    => 'json',
];